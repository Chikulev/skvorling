// Kontext v2.0 NLP, Deep Russian Morphology, Utility Scoring & Top-Pool Randomizer
// Works both in browser content scripts and in Node.js for automated testing.
(function (root) {
  'use strict';

  const CEFR_ORDER = { A1: 1, A2: 2, B1: 3, B2: 4, C1: 5 };

  const NOUN_ENDINGS = new Set([
    '', 'а', 'я', 'у', 'ю', 'ом', 'ем', 'ём', 'ой', 'ей', 'ёй', 'ою', 'ею',
    'е', 'и', 'ы', 'ов', 'ев', 'ёв', 'ам', 'ям', 'ами', 'ями', 'ах', 'ях',
    'ью', 'ие', 'ия', 'ию', 'ием', 'ии', 'ий', 'иям', 'иями', 'иях', 'ость',
    'ости', 'остью', 'остей', 'остям', 'остями', 'остях'
  ]);

  const NOUN_PLURAL_ENDINGS = new Set([
    'ы', 'и', 'ов', 'ев', 'ёв', 'ам', 'ям', 'ами', 'ями', 'ах', 'ях',
    'ия', 'ий', 'иям', 'иями', 'иях'
  ]);

  const NOUN_INSTRUMENTAL_ENDINGS = new Set(['ом', 'ем', 'ём', 'ой', 'ей', 'ёй', 'ою', 'ею', 'ью', 'ием', 'остью']);

  const ADJ_ENDINGS = new Set([
    'ый', 'ий', 'ой', 'ая', 'яя', 'ое', 'ее', 'ые', 'ие',
    'ого', 'его', 'ому', 'ему', 'ым', 'им', 'ом', 'ем',
    'ую', 'юю', 'ых', 'их', 'ыми', 'ими', 'о', 'е'
  ]);

  const VERB_ENDINGS = new Set([
    'ть', 'ться', 'ю', 'у', 'ешь', 'ёшь', 'ишь', 'ет', 'ёт', 'ит',
    'ем', 'ём', 'им', 'ете', 'ёте', 'ите', 'ют', 'ут', 'ят', 'ат',
    'л', 'ла', 'ло', 'ли', 'лся', 'лась', 'лось', 'лись'
  ]);

  const VERB_3S_ENDINGS = new Set(['ет', 'ёт', 'ит']);
  const VERB_PAST_ENDINGS = new Set(['л', 'ла', 'ло', 'ли', 'лся', 'лась', 'лось', 'лись']);

  const RU_PREPOSITIONS = new Set([
    'в', 'во', 'на', 'с', 'со', 'к', 'ко', 'о', 'об', 'обо', 'от', 'ото',
    'до', 'из', 'изо', 'у', 'по', 'под', 'подо', 'над', 'за', 'перед',
    'между', 'без', 'для', 'при', 'через', 'про', 'около', 'после', 'вместо'
  ]);

  const CYRILLIC_WORD_RE = /[А-Яа-яЁё]+/g;
  const ANY_WORD_RE = /[А-Яа-яЁёA-Za-z0-9-]+/g;

  const IMMERSION_STAGES = [
    { stage: 1, name: 'Старт', minMastered: 0, maxPerSentence: 1, maxCefr: 'A1', desc: '1 базовое очевидное слово в длинном предложении (A1)' },
    { stage: 2, name: 'Привыкание', minMastered: 15, maxPerSentence: 2, maxCefr: 'A2', desc: 'До 2 слов в предложении (A1–A2)' },
    { stage: 3, name: 'Погружение', minMastered: 45, maxPerSentence: 3, maxCefr: 'B1', desc: 'До 3 слов в предложении (A1–B1)' },
    { stage: 4, name: 'Свободный поток', minMastered: 90, maxPerSentence: 4, maxCefr: 'B2', desc: 'До 4 слов в предложении (A1–B2)' },
    { stage: 5, name: 'Профи', minMastered: 150, maxPerSentence: 5, maxCefr: 'C1', desc: 'До 5 слов в предложении (A1–C1)' }
  ];

  function getStageForMastered(masteredCount) {
    let current = IMMERSION_STAGES[0];
    for (const s of IMMERSION_STAGES) {
      if (masteredCount >= s.minMastered) current = s;
    }
    return current;
  }

  function buildIndex(dictionary, customWords, packEntries) {
    const exactMap = new Map();
    const stemBuckets = new Map();
    const participleBuckets = new Map();
    const allEntries = [...dictionary, ...(Array.isArray(packEntries) ? packEntries : [])];

    if (Array.isArray(customWords)) {
      for (const cw of customWords) {
        if (!cw || !cw.ru || !cw.en) continue;
        const ruLower = cw.ru.trim().toLowerCase();
        if (!ruLower) continue;
        allEntries.push({
          id: cw.id || ('custom_' + cw.en.trim().toLowerCase().replace(/\s+/g, '_')),
          en: cw.en.trim(),
          ipa: cw.ipa || '',
          ru: cw.ru.trim(),
          pos: cw.pos || 'n',
          level: cw.level || 'A1',
          clarity: 3,
          utility: 5,
          forms: cw.stem ? [ruLower + '*'] : [ruLower],
          cues: cw.cues || [],
          isCustom: true
        });
      }
    }

    for (const entry of allEntries) {
      // Comparative adjective exact forms
      if (Array.isArray(entry.compForms)) {
        for (const cf of entry.compForms) {
          const low = cf.toLowerCase();
          if (!exactMap.has(low)) {
            exactMap.set(low, { entry, formType: 'comp', grammarLabel: 'сравнит. степень' });
          }
        }
      }

      // Instrumental nuance exact forms
      if (entry.instNuance && Array.isArray(entry.instNuance.forms)) {
        for (const inf of entry.instNuance.forms) {
          const low = inf.toLowerCase();
          if (!exactMap.has(low)) {
            exactMap.set(low, {
              entry,
              formType: 'instrumental',
              grammarLabel: entry.instNuance.note || 'тв. падеж'
            });
          }
        }
      }

      // Explicit plural noun forms
      if (Array.isArray(entry.pluralForms)) {
        for (const pf of entry.pluralForms) {
          const low = pf.toLowerCase();
          if (!exactMap.has(low)) {
            exactMap.set(low, { entry, formType: 'plural', grammarLabel: 'мн. число' });
          }
        }
      }

      // Verb participles (e.g. работающ* + adj endings -> working)
      if (Array.isArray(entry.participleForms)) {
        for (const pf of entry.participleForms) {
          const low = pf.toLowerCase();
          const stem = low.endsWith('*') ? low.slice(0, -1) : low;
          if (stem.length < 3) continue;
          const key = stem.slice(0, 2);
          if (!participleBuckets.has(key)) participleBuckets.set(key, []);
          participleBuckets.get(key).push({ stem, entry });
        }
      }

      // Primary forms and stems
      for (const f of entry.forms || []) {
        const low = f.toLowerCase();
        if (low.endsWith('*')) {
          const stem = low.slice(0, -1);
          if (stem.length < 2) continue;
          const key = stem.slice(0, 2);
          if (!stemBuckets.has(key)) stemBuckets.set(key, []);
          stemBuckets.get(key).push({ stem, entry });
        } else {
          if (!exactMap.has(low)) {
            let formType = 'base';
            let grammarLabel = '';
            if (entry.pos === 'v') {
              if (/(?:л|ла|ло|ли|шёл|шел|шла|шли)$/.test(low)) {
                formType = 'past';
                grammarLabel = 'прош. время (Past)';
              } else if (/(?:ет|ёт|ит)$/.test(low)) {
                formType = '3s';
                grammarLabel = '3-е л. наст. (-s)';
              }
            }
            exactMap.set(low, { entry, formType, grammarLabel });
          }
        }
      }
    }

    for (const arr of stemBuckets.values()) {
      arr.sort((a, b) => b.stem.length - a.stem.length);
    }
    for (const arr of participleBuckets.values()) {
      arr.sort((a, b) => b.stem.length - a.stem.length);
    }

    return { exactMap, stemBuckets, participleBuckets, totalCount: allEntries.length };
  }

  function detectNounCaseLabel(suffix, isPlural) {
    if (isPlural) {
      if (suffix === 'ами' || suffix === 'ями') return 'тв. п. мн. ч.';
      if (suffix === 'ах' || suffix === 'ях') return 'пр. п. мн. ч.';
      if (suffix === 'ам' || suffix === 'ям') return 'дат. п. мн. ч.';
      if (suffix === 'ов' || suffix === 'ев' || suffix === 'ёв') return 'род. п. мн. ч.';
      return 'мн. число';
    }
    if (NOUN_INSTRUMENTAL_ENDINGS.has(suffix)) return 'тв. падеж (чем?)';
    if (suffix === 'е' || suffix === 'ии') return 'пр./дат. падеж';
    if (suffix === 'у' || suffix === 'ю') return 'дат./вин. падеж';
    return '';
  }

  function matchWord(wordLower, index) {
    if (!wordLower || wordLower.length < 3) return null;

    // 1. Exact forms (irregulars, plurals, comparatives, instrumental phrases)
    if (index.exactMap.has(wordLower)) {
      return index.exactMap.get(wordLower);
    }

    const bucketKey = wordLower.slice(0, 2);

    // 2. Verb participles (работающий -> working)
    const partCands = index.participleBuckets.get(bucketKey);
    if (partCands) {
      for (const { stem, entry } of partCands) {
        if (!wordLower.startsWith(stem)) continue;
        const suffix = wordLower.slice(stem.length);
        if (ADJ_ENDINGS.has(suffix)) {
          return { entry, formType: 'ing', grammarLabel: 'причастие (-ing)' };
        }
      }
    }

    // 3. Regular morphological stem + strict POS ending validation
    const candidates = index.stemBuckets.get(bucketKey);
    if (!candidates) return null;

    for (const { stem, entry } of candidates) {
      if (!wordLower.startsWith(stem)) continue;
      const suffix = wordLower.slice(stem.length);

      if (entry.pos === 'n' && NOUN_ENDINGS.has(suffix)) {
        const isPlural =
          (Array.isArray(entry.pluralForms) && entry.pluralForms.includes(wordLower)) ||
          (suffix.length > 0 && NOUN_PLURAL_ENDINGS.has(suffix) && !['и', 'ия', 'ие'].includes(suffix));
        const grammarLabel = detectNounCaseLabel(suffix, isPlural);
        return { entry, formType: isPlural ? 'plural' : 'base', grammarLabel };
      }
      if (entry.pos === 'adj' && ADJ_ENDINGS.has(suffix)) {
        return { entry, formType: 'base', grammarLabel: '' };
      }
      if (entry.pos === 'v' && VERB_ENDINGS.has(suffix)) {
        if (VERB_PAST_ENDINGS.has(suffix)) {
          return { entry, formType: 'past', grammarLabel: 'прош. время (Past)' };
        }
        if (VERB_3S_ENDINGS.has(suffix)) {
          return { entry, formType: '3s', grammarLabel: '3-е л. наст. (-s)' };
        }
        return { entry, formType: 'base', grammarLabel: suffix === 'ть' ? 'инфинитив' : 'наст. время' };
      }
      if (entry.pos === 'adv' && suffix === '') {
        return { entry, formType: 'base', grammarLabel: '' };
      }
    }

    return null;
  }

  function looksLikeRussianAdj(wordLower) {
    if (!wordLower || wordLower.length < 4) return false;
    return /(?:ым|им|ой|ей|ом|ем|ого|его|ую|юю|ые|ие|ых|их|ыми|ими)$/.test(wordLower);
  }

  function resolveEnglishSurface(match, prevTokenLower, smartGrammar) {
    const { entry, formType } = match;
    if (!smartGrammar) return entry.en;

    if (formType === 'plural' && entry.enPlural) return entry.enPlural;
    if (formType === 'past' && entry.enPast) return entry.enPast;
    if (formType === '3s' && entry.en3s) return entry.en3s;
    if (formType === 'ing' && entry.enIng) return entry.enIng;
    if (formType === 'comp' && entry.enComp) return entry.enComp;

    if (formType === 'instrumental' && entry.instNuance && entry.instNuance.enPrep) {
      // Only expand bare instrumental ("рукой" -> "by hand", "утром" -> "in the morning")
      // when NOT preceded by a Russian preposition or agreeing adjective ("правой hand", "с hand")
      const hasPrepOrAdj = prevTokenLower && (
        RU_PREPOSITIONS.has(prevTokenLower) || looksLikeRussianAdj(prevTokenLower)
      );
      if (!hasPrepOrAdj) {
        return entry.instNuance.enPrep;
      }
    }

    return entry.en;
  }

  function splitSentences(text) {
    const sentences = [];
    const abbrevRe = /(?:т\.д|т\.п|т\.е|др|пр|гг|руб|тыс|млн|млрд|см|мм|кг|ул|д|кв|рис|табл|стр)$/i;
    let start = 0;

    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (ch === '.' || ch === '!' || ch === '?' || ch === '…' || ch === '\n') {
        let end = i + 1;
        while (end < text.length && (text[end] === '.' || text[end] === '!' || text[end] === '?' || text[end] === '…')) {
          end++;
        }
        if (ch === '.' && end < text.length && text[end] !== '\n') {
          const prevChunk = text.slice(Math.max(start, i - 6), i);
          if (abbrevRe.test(prevChunk)) continue;
          if (i > 0 && /\d/.test(text[i - 1]) && /\d/.test(text[i + 1] || '')) continue;
        }
        if (end >= text.length || /[\s»"')\]]/.test(text[end]) || ch === '\n') {
          sentences.push({ start, end, text: text.slice(start, end) });
          start = end;
          i = end - 1;
        }
      }
    }

    if (start < text.length) {
      sentences.push({ start, end: text.length, text: text.slice(start) });
    }
    return sentences;
  }

  function applyCase(sourceWord, targetWord) {
    if (!sourceWord || !targetWord) return targetWord;
    if (sourceWord.length > 1 && sourceWord === sourceWord.toUpperCase()) {
      return targetWord.toUpperCase();
    }
    if (sourceWord[0] === sourceWord[0].toUpperCase() && sourceWord[0] !== sourceWord[0].toLowerCase()) {
      return targetWord[0].toUpperCase() + targetWord.slice(1);
    }
    return targetWord;
  }

  function weightedPickFromPool(pool, rng) {
    if (pool.length === 1) return pool[0];
    const minScore = pool[pool.length - 1].score;
    const weights = pool.map((c) => Math.pow(Math.max(1, c.score - minScore + 8), 1.45));
    const total = weights.reduce((a, b) => a + b, 0);
    let r = rng() * total;
    for (let i = 0; i < pool.length; i++) {
      r -= weights[i];
      if (r <= 0) return pool[i];
    }
    return pool[0];
  }

  /**
   * Analyzes a block of Russian text and returns non-overlapping replacement instructions:
   * [{ start, end, original, replacement, entry, cueMatched, grammarLabel, utility, score }]
   */
  function analyzeText(text, index, options = {}) {
    if (!text || text.length < 25) return [];

    const minSentenceWords = options.minSentenceWords ?? 7;
    const maxPerSentence = options.maxPerSentence ?? 1;
    const minWordGap = options.minWordGap ?? 2;
    const maxCefrRank = CEFR_ORDER[options.maxCefr || 'A1'] || 1;
    const progressMap = options.progressMap || {};
    const pageUsedIds = options.pageUsedIds || new Set();
    const useRandomizer = options.useRandomizer !== undefined ? !!options.useRandomizer : true;
    const randomPoolDelta = options.randomPoolDelta ?? 26;
    const smartGrammar = options.smartGrammar !== undefined ? !!options.smartGrammar : true;
    const hideMasteredWords = options.hideMasteredWords !== undefined ? !!options.hideMasteredWords : true;
    const rng = typeof options.rng === 'function' ? options.rng : Math.random;

    const sentences = splitSentences(text);
    const allReplacements = [];

    for (const sent of sentences) {
      const sentLower = sent.text.toLowerCase();

      const ruTokens = [];
      let m;
      CYRILLIC_WORD_RE.lastIndex = 0;
      while ((m = CYRILLIC_WORD_RE.exec(sent.text)) !== null) {
        ruTokens.push({
          word: m[0],
          lower: m[0].toLowerCase(),
          indexInSent: ruTokens.length,
          localStart: m.index,
          localEnd: m.index + m[0].length,
          globalStart: sent.start + m.index,
          globalEnd: sent.start + m.index + m[0].length
        });
      }

      if (ruTokens.length < minSentenceWords) continue;

      const allWords = sent.text.match(ANY_WORD_RE) || [];
      if (allWords.length === 0 || ruTokens.length / allWords.length < 0.6) continue;

      const candidates = [];
      for (let idx = 0; idx < ruTokens.length; idx++) {
        const tok = ruTokens[idx];
        const prevTok = idx > 0 ? ruTokens[idx - 1].lower : '';
        const match = matchWord(tok.lower, index);
        if (!match) continue;

        const { entry, grammarLabel } = match;
        const wordProg = progressMap[entry.id];

        if (wordProg && wordProg.status === 'hidden') continue;
        if (hideMasteredWords && wordProg && wordProg.status === 'mastered') continue;

        const entryRank = CEFR_ORDER[entry.level] || 1;
        if (!entry.isCustom && entryRank > maxCefrRank) continue;

        // Composite Score = Core Utility + Context Clarity + Anchor Cues + Sentence Length + SRS
        const utility = entry.utility || 3;
        let score = utility * 7 + (entry.clarity || 2) * 10;

        let cueMatched = false;
        let cueCount = 0;
        if (Array.isArray(entry.cues) && entry.cues.length > 0) {
          for (const cue of entry.cues) {
            if (sentLower.includes(cue)) {
              cueCount++;
              cueMatched = true;
            }
          }
        }
        if (cueCount > 0) {
          // Diminishing returns: 1st anchor +24, additional anchors +8 (capped at +32)
          score += Math.min(32, 24 + (cueCount - 1) * 8);
        }

        if (ruTokens.length >= 10) score += 6;
        if (ruTokens.length >= 16) score += 5;
        if (entry.pos === 'n') score += 6;
        if (match.formType === 'ing' || match.formType === '3s' || match.formType === 'past' || match.formType === 'comp') {
          score += 4;
        }
        if (entry.pack) score += 6;
        if (entry.isCustom) score += 30;

        if (wordProg) {
          if (wordProg.status === 'mastered') {
            score -= 20;
          } else if ((wordProg.hovers || 0) > 0) {
            score += 18;
          } else if ((wordProg.seen || 0) > 0) {
            score += 8;
          }
        } else {
          score += 5;
        }

        if (pageUsedIds.has(entry.id)) {
          score -= 14;
        }

        const rawSurface = resolveEnglishSurface(match, prevTok, smartGrammar);
        const replacement = applyCase(tok.word, rawSurface);

        candidates.push({
          token: tok,
          entry,
          replacement,
          cueMatched,
          grammarLabel: grammarLabel || '',
          utility,
          score
        });
      }

      if (candidates.length === 0) continue;

      const densityCap = Math.min(
        maxPerSentence,
        Math.max(1, Math.floor(ruTokens.length / 4))
      );

      const chosen = [];
      const usedInSentence = new Set();

      // Iteratively pick up to densityCap candidates using either Top-Pool Randomizer or strict top-1
      let remaining = candidates.slice().sort((a, b) => b.score - a.score);

      while (chosen.length < densityCap && remaining.length > 0) {
        // Filter out already-used IDs and words too close to already chosen tokens
        remaining = remaining.filter((cand) => {
          if (usedInSentence.has(cand.entry.id)) return false;
          return !chosen.some((c) => Math.abs(c.token.indexInSent - cand.token.indexInSent) <= minWordGap);
        });
        if (remaining.length === 0) break;

        let picked;
        if (useRandomizer) {
          const topScore = remaining[0].score;
          const pool = remaining
            .filter((c) => topScore - c.score <= randomPoolDelta)
            .slice(0, 5);
          picked = weightedPickFromPool(pool, rng);
        } else {
          picked = remaining[0];
        }

        chosen.push(picked);
        usedInSentence.add(picked.entry.id);
        pageUsedIds.add(picked.entry.id);
        remaining = remaining.filter((c) => c !== picked);
      }

      for (const c of chosen) {
        allReplacements.push({
          start: c.token.globalStart,
          end: c.token.globalEnd,
          original: c.token.word,
          replacement: c.replacement,
          entry: c.entry,
          cueMatched: c.cueMatched,
          grammarLabel: c.grammarLabel,
          utility: c.utility,
          score: c.score
        });
      }
    }

    allReplacements.sort((a, b) => a.start - b.start);
    return allReplacements;
  }

  const api = {
    CEFR_ORDER,
    IMMERSION_STAGES,
    getStageForMastered,
    buildIndex,
    matchWord,
    splitSentences,
    applyCase,
    analyzeText
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = api;
  } else {
    root.KontextNLP = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);

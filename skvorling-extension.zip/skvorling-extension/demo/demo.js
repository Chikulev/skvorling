'use strict';

(async function initDemoControls() {
  const Storage = window.KontextStorage;
  const state = await Storage.loadState();

  const buttons = document.querySelectorAll('.pill-btn[data-density]');
  const btnAuto = document.getElementById('btnDemoAuto');
  const btnNav = document.getElementById('btnDemoNav');
  const btnShuffle = document.getElementById('btnDemoShuffle');

  function syncActive() {
    buttons.forEach((b) => {
      const match = !state.settings.autoProgression &&
        Number(b.dataset.density) === Number(state.settings.manualMaxPerSentence);
      b.classList.toggle('active', match);
    });
    if (btnAuto) {
      btnAuto.classList.toggle('active', !!state.settings.autoProgression);
    }
  }

  syncActive();

  if (btnNav) {
    btnNav.addEventListener('click', () => {
      if (window.KontextPageAPI) window.KontextPageAPI.openNavigator();
    });
  }

  if (btnShuffle) {
    btnShuffle.addEventListener('click', () => {
      if (window.KontextPageAPI) window.KontextPageAPI.reshuffle();
    });
  }

  buttons.forEach((btn) => {
    btn.addEventListener('click', async () => {
      const st = await Storage.loadState();
      st.settings.enabled = true;
      st.settings.autoProgression = false;
      st.settings.manualMaxPerSentence = Number(btn.dataset.density);
      st.settings.manualMaxCefr = btn.dataset.cefr;
      await Storage.saveState(st);
      window.location.reload();
    });
  });

  if (btnAuto) {
    btnAuto.addEventListener('click', async () => {
      const st = await Storage.loadState();
      st.settings.enabled = true;
      st.settings.autoProgression = true;
      await Storage.saveState(st);
      window.location.reload();
    });
  }
})();

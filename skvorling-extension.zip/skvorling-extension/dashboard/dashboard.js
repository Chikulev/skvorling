'use strict';

(async function initDashboard() {
  const NLP = window.KontextNLP;
  const Storage = window.KontextStorage;
  const DICT = window.KONTEXT_DICTIONARY || [];
  const PACKS = window.KONTEXT_PACKS || {};
  const getActivePackEntries = window.getActivePackEntries || (() => []);

  let state = await Storage.loadState();

  function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2000);
  }

  function speak(word) {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(word);
    u.lang = state.settings.accent || 'en-US';
    u.rate = 0.92;
    window.speechSynthesis.speak(u);
  }

  // Navigation tabs
  document.getElementById('mainNav').addEventListener('click', (e) => {
    const btn = e.target.closest('.nav-item');
    if (!btn) return;
    document.querySelectorAll('.nav-item').forEach((b) => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach((p) => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
  });

  function renderOverview() {
    const eff = Storage.getEffectiveConfig(state, NLP);
    const today = (state.stats.daily && state.stats.daily[Storage.getTodayKey()]) || { seen: 0 };

    document.getElementById('ovStageChip').textContent = `Уровень ${eff.stageInfo.stage} · ${eff.stageInfo.name}`;
    document.getElementById('kpiMastered').textContent = String(eff.masteredCount);
    const activePackCount = getActivePackEntries(state.settings.enabledPacks).length;
    document.getElementById('kpiTotalDict').textContent = `из ${DICT.length + activePackCount + state.customWords.length} активных слов`;
    document.getElementById('kpiSeen').textContent = String(state.stats.totalSeen || 0);
    document.getElementById('kpiToday').textContent = `сегодня: ${today.seen || 0}`;
    document.getElementById('kpiHovers').textContent = String(state.stats.totalHovers || 0);
    document.getElementById('kpiStreak').textContent = String(state.stats.streakDays || 0);

    const total = (state.stats.totalSeen || 0) + (state.stats.totalHovers || 0);
    const acc = total > 0 ? Math.round(((state.stats.totalSeen || 0) / total) * 100) : null;
    document.getElementById('kpiAccuracy').textContent = acc !== null ? `без подсказки: ${acc}%` : 'пока нет данных';

    // CEFR bars
    const cefrEl = document.getElementById('cefrBars');
    cefrEl.innerHTML = '';
    for (const lvl of ['A1', 'A2', 'B1', 'B2', 'C1']) {
      const words = DICT.filter((w) => w.level === lvl);
      const mastered = words.filter((w) => state.progress[w.id] && state.progress[w.id].status === 'mastered').length;
      const pct = words.length ? Math.round((mastered / words.length) * 100) : 0;
      const row = document.createElement('div');
      row.className = 'cefr-row';
      row.innerHTML = `
        <span class="cefr-tag">${lvl}</span>
        <div class="bar-track"><div class="bar-fill" style="width:${pct}%"></div></div>
        <span class="cefr-num">${mastered} / ${words.length}</span>
      `;
      cefrEl.appendChild(row);
    }

    // Hard words
    const hardEl = document.getElementById('hardList');
    const hardWords = DICT
      .map((w) => ({ w, p: state.progress[w.id] }))
      .filter((x) => x.p && (x.p.hovers || 0) > 0 && x.p.status !== 'mastered' && x.p.status !== 'hidden')
      .sort((a, b) => (b.p.hovers || 0) - (a.p.hovers || 0))
      .slice(0, 6);

    if (hardWords.length === 0) {
      hardEl.innerHTML = '<div class="hard-meta">Пока нет сложных слов — читайте статьи, и здесь появятся слова, на которые вы наводили чаще всего.</div>';
    } else {
      hardEl.innerHTML = '';
      for (const { w, p } of hardWords) {
        const item = document.createElement('div');
        item.className = 'hard-item';
        item.innerHTML = `
          <div>
            <span class="hard-word">${w.en}</span> — ${w.ru}
            <div class="hard-meta">Подсказок: ${p.hovers} · ${w.level}</div>
          </div>
          <div>
            <button type="button" class="mini-btn" data-speak="${w.en}">🔊</button>
            <button type="button" class="mini-btn" data-know="${w.id}">✓ Знаю</button>
          </div>
        `;
        hardEl.appendChild(item);
      }
      hardEl.querySelectorAll('[data-speak]').forEach((b) => b.addEventListener('click', () => speak(b.dataset.speak)));
      hardEl.querySelectorAll('[data-know]').forEach((b) => b.addEventListener('click', async () => {
        Storage.setWordStatus(state, b.dataset.know, 'mastered');
        await Storage.saveState(state);
        renderAll();
        showToast('Слово отмечено как освоенное');
      }));
    }

    // Roadmap
    const roadEl = document.getElementById('roadmapGrid');
    roadEl.innerHTML = '';
    for (const s of NLP.IMMERSION_STAGES) {
      const unlocked = eff.masteredCount >= s.minMastered;
      const isCurrent = eff.stageInfo.stage === s.stage;
      const card = document.createElement('div');
      card.className = `stage-card ${unlocked ? 'unlocked' : ''} ${isCurrent ? 'current' : ''}`;
      card.innerHTML = `
        <span class="stage-num">Уровень ${s.stage} · ${s.maxCefr}</span>
        <span class="stage-name">${s.name}</span>
        <span class="stage-meta">до ${s.maxPerSentence} сл./предл.</span>
        <span class="stage-meta">от ${s.minMastered} освоенных</span>
      `;
      roadEl.appendChild(card);
    }
  }

  function renderVocab() {
    const q = (document.getElementById('vocabSearch').value || '').trim().toLowerCase();
    const lvl = document.getElementById('vocabLevel').value;
    const stFilter = document.getElementById('vocabStatus').value;
    const tbody = document.getElementById('vocabBody');

    const rows = DICT.filter((w) => {
      if (lvl !== 'ALL' && w.level !== lvl) return false;
      const p = state.progress[w.id];
      const st = p ? p.status : 'new';
      if (stFilter !== 'ALL' && st !== stFilter) return false;
      if (q && !w.en.toLowerCase().includes(q) && !w.ru.toLowerCase().includes(q)) return false;
      return true;
    }).slice(0, 150);

    tbody.innerHTML = '';
    for (const w of rows) {
      const p = state.progress[w.id];
      const st = p ? p.status : 'new';
      const stText = { mastered: 'Освоено', learning: 'Изучаю', hidden: 'Скрыто', new: 'Новое' }[st];
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><span class="vocab-en">${w.en}</span><span class="vocab-ipa">${w.ipa || ''}</span></td>
        <td>${w.ru}</td>
        <td>${w.level}</td>
        <td>${p ? `${p.seen || 0} / ${p.hovers || 0}` : '0 / 0'}</td>
        <td><span class="pill pill-${st}">${stText}</span></td>
        <td>
          <button type="button" class="mini-btn" data-act="speak" data-en="${w.en}">🔊</button>
          <button type="button" class="mini-btn" data-act="mastered" data-id="${w.id}">✓</button>
          <button type="button" class="mini-btn" data-act="hidden" data-id="${w.id}">✕</button>
        </td>
      `;
      tbody.appendChild(tr);
    }
  }

  document.getElementById('vocabBody').addEventListener('click', async (e) => {
    const btn = e.target.closest('button[data-act]');
    if (!btn) return;
    if (btn.dataset.act === 'speak') {
      speak(btn.dataset.en);
      return;
    }
    Storage.setWordStatus(state, btn.dataset.id, btn.dataset.act);
    await Storage.saveState(state);
    renderAll();
    showToast('Статус слова обновлён');
  });

  ['vocabSearch', 'vocabLevel', 'vocabStatus'].forEach((id) => {
    document.getElementById(id).addEventListener('input', renderVocab);
  });

  // Custom words
  function renderCustom() {
    const list = document.getElementById('customList');
    document.getElementById('customCount').textContent = String(state.customWords.length);
    if (state.customWords.length === 0) {
      list.innerHTML = '<div class="hard-meta">Вы ещё не добавляли свои слова.</div>';
      return;
    }
    list.innerHTML = '';
    state.customWords.forEach((cw, idx) => {
      const div = document.createElement('div');
      div.className = 'hard-item';
      div.innerHTML = `
        <div><strong>${cw.en}</strong> — ${cw.ru} <span class="hard-meta">${cw.ipa || ''} ${cw.stem ? '(с окончаниями)' : '(точное)'}</span></div>
        <button type="button" class="mini-btn" data-del="${idx}">Удалить</button>
      `;
      list.appendChild(div);
    });
    list.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', async () => {
      state.customWords.splice(Number(b.dataset.del), 1);
      await Storage.saveState(state);
      renderAll();
      showToast('Слово удалено');
    }));
  }

  document.getElementById('customForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const ru = document.getElementById('cwRu').value.trim();
    const en = document.getElementById('cwEn').value.trim();
    const ipa = document.getElementById('cwIpa').value.trim();
    const pos = document.getElementById('cwPos').value;
    const stem = document.getElementById('cwStem').checked;
    if (!ru || !en) return;
    state.customWords.push({ id: 'custom_' + Date.now(), ru, en, ipa, pos, stem });
    await Storage.saveState(state);
    e.target.reset();
    document.getElementById('cwStem').checked = true;
    renderAll();
    showToast('Слово добавлено в словарь');
  });

  // Settings
  function renderSettings() {
    const s = state.settings;
    document.getElementById('setMinWords').value = String(s.minSentenceWords);
    document.getElementById('lblMinWords').textContent = String(s.minSentenceWords);
    document.getElementById('setMinGap').value = String(s.minWordGap);
    document.getElementById('lblMinGap').textContent = String(s.minWordGap);
    document.getElementById('setAccent').value = s.accent || 'en-US';
    document.getElementById('setAutoSpeak').checked = !!s.autoSpeakOnHover;
    document.getElementById('setShowIpa').checked = !!s.showIpa;
    document.getElementById('setShowCue').checked = !!s.showCueBadge;
    document.getElementById('setRandomizer').checked = s.useRandomizer !== false;
    document.getElementById('setSmartGrammar').checked = s.smartGrammar !== false;
    document.getElementById('setHideMastered').checked = s.hideMasteredWords !== false;
    const packsBox = document.getElementById('dashPacksList');
    if (packsBox) {
      const activeSet = new Set(s.enabledPacks || []);
      packsBox.innerHTML = '';
      Object.values(PACKS).forEach((p) => {
        const lbl = document.createElement('label');
        lbl.className = 'hard-item';
        lbl.style.cursor = 'pointer';
        lbl.innerHTML = `<div><strong>${p.icon} ${p.name}</strong><div class="hard-meta">${p.entries.length} слов · ${p.description}</div></div><input type="checkbox" data-dash-pack="${p.id}" ${activeSet.has(p.id) ? 'checked' : ''}>`;
        packsBox.appendChild(lbl);
      });
      packsBox.querySelectorAll('input[data-dash-pack]').forEach((inp) => {
        inp.addEventListener('change', () => {
          const next = new Set(state.settings.enabledPacks || []);
          if (inp.checked) next.add(inp.dataset.dashPack);
          else next.delete(inp.dataset.dashPack);
          saveSetting((st) => { st.enabledPacks = Array.from(next); });
          renderOverview();
        });
      });
    }
    document.getElementById('setUpdateUrl').value = s.updateManifestUrl || '';
    const ver = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : '2.0.0';
    document.getElementById('lblVersion').textContent = 'v' + ver;
    document.getElementById('setExcluded').value = (s.excludedDomains || []).join('\n');
  }

  async function saveSetting(fn) {
    fn(state.settings);
    await Storage.saveState(state);
    showToast('Настройки сохранены');
  }

  document.getElementById('setMinWords').addEventListener('input', (e) => {
    document.getElementById('lblMinWords').textContent = e.target.value;
  });
  document.getElementById('setMinWords').addEventListener('change', (e) => {
    saveSetting((s) => { s.minSentenceWords = Number(e.target.value); });
  });
  document.getElementById('setMinGap').addEventListener('input', (e) => {
    document.getElementById('lblMinGap').textContent = e.target.value;
  });
  document.getElementById('setMinGap').addEventListener('change', (e) => {
    saveSetting((s) => { s.minWordGap = Number(e.target.value); });
  });
  document.getElementById('setAccent').addEventListener('change', (e) => {
    saveSetting((s) => { s.accent = e.target.value; });
  });
  document.getElementById('setAutoSpeak').addEventListener('change', (e) => {
    saveSetting((s) => { s.autoSpeakOnHover = e.target.checked; });
  });
  document.getElementById('setShowIpa').addEventListener('change', (e) => {
    saveSetting((s) => { s.showIpa = e.target.checked; });
  });
  document.getElementById('setShowCue').addEventListener('change', (e) => {
    saveSetting((s) => { s.showCueBadge = e.target.checked; });
  });
  document.getElementById('btnSaveExcluded').addEventListener('click', () => {
    const raw = document.getElementById('setExcluded').value;
    const domains = raw.split(/\r?\n/).map((x) => x.trim().toLowerCase()).filter(Boolean);
    saveSetting((s) => { s.excludedDomains = domains; });
  });


  document.getElementById('setRandomizer').addEventListener('change', (e) => {
    saveSetting((s) => { s.useRandomizer = e.target.checked; });
  });
  document.getElementById('setSmartGrammar').addEventListener('change', (e) => {
    saveSetting((s) => { s.smartGrammar = e.target.checked; });
  });
  document.getElementById('setHideMastered').addEventListener('change', (e) => {
    saveSetting((s) => { s.hideMasteredWords = e.target.checked; });
  });
  document.getElementById('btnSkipA1').addEventListener('click', async () => {
    if (!confirm('Отметить все слова уровня A1 как уже известные (Освоено)?')) return;
    for (const w of DICT) {
      if (w.level === 'A1') Storage.setWordStatus(state, w.id, 'mastered');
    }
    await Storage.saveState(state);
    renderAll();
    showToast('Все слова A1 отмечены как изученные!');
  });
  document.getElementById('setUpdateUrl').addEventListener('change', (e) => {
    saveSetting((s) => { s.updateManifestUrl = e.target.value.trim(); });
  });

  function compareSemver(a, b) {
    const pa = String(a || '0.0.0').replace(/^v/, '').split('.').map(Number);
    const pb = String(b || '0.0.0').replace(/^v/, '').split('.').map(Number);
    for (let i = 0; i < 3; i++) {
      if ((pa[i] || 0) > (pb[i] || 0)) return 1;
      if ((pa[i] || 0) < (pb[i] || 0)) return -1;
    }
    return 0;
  }

  document.getElementById('btnCheckUpdate').addEventListener('click', async () => {
    const statusEl = document.getElementById('updateStatus');
    const url = document.getElementById('setUpdateUrl').value.trim();
    if (!url) {
      statusEl.textContent = 'Укажите URL вашего update.json (формат: {"version":"2.1.0","downloadUrl":"...","notes":"..."}) или публикуйте обновления через Chrome Web Store.';
      return;
    }
    statusEl.textContent = 'Проверяем обновления...';
    try {
      const resp = await fetch(url, { cache: 'no-store' });
      if (!resp.ok) throw new Error('HTTP ' + resp.status);
      const data = await resp.json();
      const curVer = (chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : '2.0.0';
      if (data.version && compareSemver(data.version, curVer) > 0) {
        statusEl.innerHTML = `Доступна новая версия <strong>v${data.version}</strong>${data.notes ? ' — ' + data.notes : ''}${data.downloadUrl ? ` · <a href="${data.downloadUrl}" target="_blank" style="color:#6ee7b7;">Скачать</a>` : ''}`;
      } else {
        statusEl.textContent = `У вас установлена актуальная версия (v${curVer}).`;
      }
    } catch (err) {
      statusEl.textContent = 'Не удалось проверить обновления: ' + (err.message || 'ошибка сети');
    }
  });

  document.getElementById('fileImportPack').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const pack = JSON.parse(await file.text());
      const items = Array.isArray(pack) ? pack : (Array.isArray(pack.words) ? pack.words : []);
      if (items.length === 0) throw new Error('Пустой пакет');
      const existing = new Set(state.customWords.map((w) => (w.ru + '|' + w.en).toLowerCase()));
      let added = 0;
      for (const item of items) {
        if (!item.ru || !item.en) continue;
        const key = (item.ru + '|' + item.en).toLowerCase();
        if (existing.has(key)) continue;
        state.customWords.push({
          id: 'pack_' + Date.now() + '_' + added,
          ru: String(item.ru).trim(),
          en: String(item.en).trim(),
          ipa: item.ipa ? String(item.ipa).trim() : '',
          pos: item.pos || 'n',
          stem: item.stem !== false
        });
        existing.add(key);
        added++;
      }
      await Storage.saveState(state);
      renderAll();
      showToast(`Импортировано новых слов: ${added}`);
    } catch (_) {
      showToast('Ошибка: нужен JSON-массив объектов {ru, en}');
    }
  });

  // Export / Import / Reset
  document.getElementById('btnExport').addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `skvorling-backup-${Storage.getTodayKey()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  });

  document.getElementById('fileImport').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text());
      state = Storage.mergeWithDefaults(parsed);
      await Storage.saveState(state);
      renderAll();
      showToast('Прогресс успешно импортирован');
    } catch (_) {
      showToast('Ошибка: некорректный JSON-файл');
    }
  });

  document.getElementById('btnReset').addEventListener('click', async () => {
    if (!confirm('Сбросить весь прогресс обучения и статистику?')) return;
    state = Storage.createDefaultState();
    await Storage.saveState(state);
    renderAll();
    showToast('Прогресс сброшен');
  });

  const dashThemeGroup = document.getElementById('dashThemeGroup');
  if (dashThemeGroup) {
    dashThemeGroup.addEventListener('click', async (e) => {
      const btn = e.target.closest('button[data-theme]');
      if (!btn) return;
      state.settings.uiTheme = btn.dataset.theme;
      await Storage.saveState(state);
      document.body.dataset.theme = state.settings.uiTheme;
      showToast('Тема обновлена');
    });
  }

  function renderAll() {
    document.body.dataset.theme = state.settings.uiTheme || 'colorful';
    renderOverview();
    renderVocab();
    renderCustom();
    renderSettings();
  }

  renderAll();
})();
